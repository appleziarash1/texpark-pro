/* Texpark Pro — Steadfast courier link.

   A parcel's Steadfast tracking is tied to the memo/order that promised it, so the
   delivery status can come back without the owner retyping it: a delivered parcel
   marks the memo delivered, a returned one records the parcel came back.

   Two honest limits, both surfaced in the UI rather than hidden:

   * Steadfast's status API reports delivery at the parcel level (delivered /
     partial / cancelled / returned). It does not report how many pieces came back —
     that number is confirmed by the person holding the parcel, so a returned status
     opens the Return screen for the owner instead of inventing a quantity.
   * Whether returned goods are sellable (Good) or damaged is the owner's call, so it
     is a setting, not a guess.

   The API key and secret are per-device (`LOCAL_SETTING_KEYS`), never synced: they
   are the shop's credentials, and a second device has its own.

   Steadfast answers with `Access-Control-Allow-Origin: *`, so a browser can call it
   directly — no server, and this stays on the free plan. */

const STEADFAST_API = 'https://portal.packzy.com/api/v1';
const COURIER_KEY_KEY = 'texpark_pro_courier_key';
const COURIER_SECRET_KEY = 'texpark_pro_courier_secret';

/* Where the per-device credentials live. Kept out of `db` and localStorage's
   app JSON on purpose so a future backup/sync path cannot pick them up by accident. */
function courierKey() {
  try { return (localStorage.getItem(COURIER_KEY_KEY) || '').trim(); } catch (e) { return ''; }
}
function courierSecret() {
  try { return (localStorage.getItem(COURIER_SECRET_KEY) || '').trim(); } catch (e) { return ''; }
}
function courierConfigured() { return !!(courierKey() && courierSecret()); }
function courierEnabled() {
  return courierConfigured() && db.settings && db.settings.courierEnabled !== false;
}
function courierAutoCod() { return !!(db.settings && db.settings.courierAutoCod !== false); }
function courierAutoReturnGood() { return !!(db.settings && db.settings.courierAutoReturnGood !== false); }

/* Statuses Steadfast returns. The *_approval_pending ones are not final: the balance
   has not been updated, so the app must not treat them as delivered/cancelled yet. */
const COURIER_STATUS_LABEL = {
  pending: 'Pending', in_review: 'In Review', hold: 'On Hold',
  delivered: 'Delivered', partial_delivered: 'Partially Delivered',
  cancelled: 'Cancelled', returned: 'Returned',
  delivered_approval_pending: 'Delivered (awaiting approval)',
  partial_delivered_approval_pending: 'Partial (awaiting approval)',
  cancelled_approval_pending: 'Cancelled (awaiting approval)',
  unknown_approval_pending: 'Unknown (awaiting approval)',
  unknown: 'Unknown'
};
/* A status only "counts" once it is final. The approval-pending ones read as their
   base status for display, but the app waits before moving stock or a due. */
const COURIER_FINAL = ['delivered', 'partial_delivered', 'cancelled', 'returned'];
function courierStatusFinal_(status) { return COURIER_FINAL.indexOf(String(status || '')) !== -1; }
function courierStatusLabel_(status) {
  const s = String(status || '');
  return COURIER_STATUS_LABEL[s] || s || 'Unknown';
}
function courierBaseStatus_(status) {
  return String(status || '').replace(/_approval_pending$/, '');
}

/* The consignment id out of a tracking link or a raw id. Accepts the shapes Steadfast
   and its SMS use, and returns '' rather than guessing when nothing matches. */
function extractConsignment_(text) {
  const t = String(text == null ? '' : text).trim();
  if (!t) return '';
  if (/^\d{3,}$/.test(t)) return t;
  /* A short alphanumeric token is itself a tracking code (Steadfast codes look like
     this). The 4-char floor keeps a stray word from being read as an id. */
  if (/^[A-Za-z0-9._-]{4,}$/.test(t) && !/^https?:/i.test(t)) return t;
  const m = t.match(/trackingCode=([A-Za-z0-9._-]+)/i) ||
            t.match(/(?:cid|consignment[_-]?id)[=\/]([A-Za-z0-9._-]+)/i) ||
            t.match(/\/(?:t|track)\/([A-Za-z0-9._-]+)/i);
  return m ? m[1] : '';
}

/* Build the Steadfast request. Kept as a pure function from stored state so a test
   can assert exactly what a status check would send without a socket. */
function courierRequestFor_(ord) {
  const id = String((ord && (ord.consignmentId || '')) || '').trim() ||
             extractConsignment_(ord && ord.trackingUrl);
  if (!id) return null;
  if (/^\d+$/.test(id)) return { url: STEADFAST_API + '/status_by_cid/' + encodeURIComponent(id), kind: 'cid' };
  return { url: STEADFAST_API + '/status_by_trackingcode/' + encodeURIComponent(id), kind: 'tracking' };
}

/* Parse the status JSON. Returns {status, cod} or {error}. Pure — the tests drive it
   with the exact shapes Steadfast documents. */
function parseCourierStatus_(json) {
  const j = json || {};
  if (j.status && j.status !== 200) return { error: String(j.message || 'Steadfast refused the request') };
  const d = j.delivery_status || j.data || j.consignment || {};
  const status = d.status || d.delivery_status || j.delivery_status || '';
  if (!status) return { error: 'No delivery status in the reply' };
  return { status: String(status), cod: num(d.cod_amount != null ? d.cod_amount : j.cod_amount) };
}

/* The HTTP call, isolated so tests stub exactly one seam. */
async function courierFetch_(req) {
  if (!courierConfigured()) return { error: 'Courier API key/secret are not set (Settings → Courier).' };
  try {
    const res = await fetch(req.url, {
      headers: { 'Api-Key': courierKey(), 'Secret-Key': courierSecret(), 'Content-Type': 'application/json' }
    });
    const txt = await res.text();
    let j = null; try { j = JSON.parse(txt); } catch (e) { /* not JSON */ }
    if (j === null) {
      return { error: res.status === 401 || res.status === 403
        ? 'Steadfast rejected the API key (HTTP ' + res.status + '). Check Settings → Courier.'
        : 'Steadfast did not return JSON (HTTP ' + res.status + ').' };
    }
    return parseCourierStatus_(j);
  } catch (e) {
    return { error: 'Could not reach Steadfast: ' + ((e && e.message) || e) };
  }
}

/* A small badge on the order card so a delivered/returned parcel is visible at a
   glance from the board, without opening every order. */
function ordCourierBadgeHTML(o) {
  if (!o) return '';
  const hasId = !!(o.consignmentId || extractConsignment_(o.trackingUrl));
  if (!o.courierStatus && !hasId) return '';
  const s = o.courierStatus || '';
  const cls = s === 'delivered' ? 'ok'
    : (s === 'cancelled' || s === 'returned' ? 'danger' : 'warn');
  const label = s ? courierStatusLabel_(s) : 'Tracking linked';
  const link = o.trackingUrl ? String(o.trackingUrl).trim() : '';
  return '<div class="ocourier"><span class="pill ' + cls + '">🚚 ' + esc(label) + '</span>' +
    (link ? '<a href="' + esc(link) + '" target="_blank" rel="noopener" onclick="event.stopPropagation()">Track ↗</a>' : '') +
    '</div>';
}

/* ============================ mapping a status onto the business ============================
   This is the only place a courier status changes records, and it is deliberately
   additive: it never lowers a delivered quantity, never fabricates a return qty, and
   records why it acted in the order history. */

/* Link a returned parcel's stock back in. Pieces are taken from the memo's own lines,
   capped at what is still pending, so a returned status can never put back more than
   was sold. When nothing is pending it records the fact without touching stock. */
function applyCourierReturn(memo, qtyCap) {
  if (!memo) return { qty: 0 };
  const pending = pendingQtyOf(memo);
  if (pending <= 0) return { qty: 0, note: 'nothing pending to return' };
  let left = num(qtyCap) > 0 ? Math.min(num(qtyCap), pending) : pending;
  const items = [];
  if (left > 0) {
    (memo.items || []).forEach(it => {
      if (left <= 0 || !it.productId) return;
      const alreadyBack = (db.returns || [])
        .filter(r => r.memoId === memo.id)
        .reduce((a, r) => a + ((r.items || []).filter(x => x.productId === it.productId)
          .reduce((b, x) => b + num(x.qty), 0)), 0);
      const avail = Math.max(0, num(it.qty) - num(deliveredQtyOf(memo.id)) - alreadyBack);
      const take = Math.min(left, avail);
      if (take > 0) { items.push({ productId: it.productId, productName: it.productName, qty: take }); left -= take; }
    });
  }
  if (!items.length) return { qty: 0, note: 'nothing pending to return' };
  const qty = items.reduce((a, x) => a + num(x.qty), 0);
  const ret = {
    id: id(), memoId: memo.id, memoNo: memo.memoNo, date: today(),
    items, qty, condition: courierAutoReturnGood() ? 'good' : 'damaged',
    note: 'Auto from Steadfast status', returnedAt: new Date().toISOString(),
    source: 'steadfast'
  };
  db.returns.push(ret);
  applyReturnToStock(ret);
  return { qty, items };
}

/* Mark a memo delivered (and, when the setting is on, take COD off the due). Skips
   silently when there is nothing pending, so a re-sync never double-counts. */
function applyCourierDelivered(memo, codAmount) {
  if (!memo) return null;
  const pending = pendingQtyOf(memo);
  if (pending <= 0) return null;
  let collected = courierAutoCod() ? Math.max(0, num(codAmount)) : 0;
  const owed = memoRemainingDue(memo);
  if (collected > owed) collected = owed;
  const deliveryId = id();
  db.deliveries.push({
    id: deliveryId, memoId: memo.id, qty: pending, date: today(),
    driver: 'Steadfast', vehicle: '', receiver: '', note: 'Auto from Steadfast status',
    status: 'Delivered', source: 'steadfast'
  });
  let payment = null;
  if (collected > 0) {
    payment = {
      id: id(), memoId: memo.id, deliveryId, customerId: customerIdForMemo_(memo),
      date: today(), amount: collected, method: 'Cash',
      note: 'COD collected on Steadfast delivery ' + memo.memoNo
    };
    db.payments.push(payment);
  }
  return { delivery: db.deliveries[db.deliveries.length - 1], payment, collected };
}

/* Apply one status to one order. Returns a short note for the caller to show; the
   caller commits and pushes once, so a batch of orders is one save. */
function courierApplyStatus_(ord, status, cod) {
  const base = courierBaseStatus_(status);
  const memo = memoForOrder_(ord);
  const notes = [];
  if (base === 'delivered') {
    if (ord.status !== 'delivered') { ord.status = 'delivered'; notes.push('order → Delivered'); }
    if (memo) {
      const r = applyCourierDelivered(memo, cod);
      if (r) {
        notes.push('memo ' + memo.memoNo + ' delivered (' + r.delivery.qty + ' pcs)');
        if (r.collected > 0) notes.push('COD ' + money(r.collected) + ' off the due');
      }
    }
  } else if (base === 'partial_delivered') {
    notes.push('partially delivered');
  } else if (base === 'cancelled') {
    if (ord.status !== 'delivered') ord.status = 'dispatched';
    notes.push('cancelled at the courier');
  } else if (base === 'returned') {
    /* Pieces are not in the status reply, so the owner confirms the qty — but the
       fact that goods came back adds stock right away when the setting asks for it. */
    if (memo) { const r = applyCourierReturn(memo, 0); if (r.qty > 0) notes.push('return ' + r.qty + ' pcs back to stock'); }
    notes.push('returned');
  } else if (base === 'hold') {
    notes.push('on hold at the courier');
  }
  return notes.join(', ');
}

/* The pure "which order needs checking" filter, so a board of 200 orders does not
   make 200 requests on every open. Only unsynced, active orders with an id are polled,
   newest change first, and the caller caps the batch. */
function courierSyncTargets_(orders, max) {
  const list = (orders || []).filter(o =>
    o && (o.consignmentId || extractConsignment_(o.trackingUrl)) &&
    o.courierStatus !== 'delivered' && o.courierStatus !== 'cancelled' &&
    o.courierStatus !== 'returned' && o.status !== 'delivered'
  );
  list.sort((a, b) => String(a.deliveryDate || '').localeCompare(String(b.deliveryDate || '')));
  return list.slice(0, max || 8);
}

/* Sync a list of orders. One commit for the whole batch. `fetchOne` is injectable for
   tests; production passes nothing and uses courierFetch_. */
async function courierSyncOrders(orders, fetchOne) {
  const get = fetchOne || courierFetch_;
  let checked = 0, changed = 0;
  const lines = [];
  for (const ord of orders) {
    const req = courierRequestFor_(ord);
    if (!req) continue;
    checked++;
    const resp = await get(req);
    if (resp.error) { lines.push((ord.orderNo || '') + ': ' + resp.error); continue; }
    /* Always record what Steadfast last said, even if it maps to nothing yet, so the
       board shows a status rather than a silent absence. */
    const before = ord.courierStatus || '';
    ord.courierStatus = resp.status;
    ord.courierCod = resp.cod;
    ord.courierCheckedAt = new Date().toISOString();
    const note = courierApplyStatus_(ord, resp.status, resp.cod);
    if (note) lines.push((ord.orderNo || '') + ': ' + note);
    if (before !== resp.status || note) changed++;
  }
  if (changed) commit();
  return { checked, changed, lines };
}

/* ============================ UI actions ============================ */

/* The memo/order link: a memo an order promises, matched by memoNo or memoId. */
function memoForOrder_(ord) {
  if (!ord) return null;
  if (ord.memoId) { const m = (db.memos || []).find(x => x.id === ord.memoId); if (m) return m; }
  const no = String(ord.memoNo || '').trim();
  if (no) return (db.memos || []).find(x => String(x.memoNo || '').trim() === no) || null;
  return null;
}
function orderForMemo_(memo) {
  if (!memo) return null;
  return (db.orders || []).find(o => o.memoId === memo.id ||
    (o.memoNo && String(o.memoNo).trim() === String(memo.memoNo || '').trim())) || null;
}

/* Pull the consignment id out of whatever the owner pasted into the tracking field,
   so they can paste the SMS link and carry on. */
function orderTrackingChanged() {
  const url = document.getElementById('ordTrackingUrl');
  const cid = document.getElementById('ordConsignment');
  if (!url || !cid) return;
  const found = extractConsignment_(url.value);
  if (found && !String(cid.value || '').trim()) cid.value = found;
}

function syncOrderCourier() {
  const oid = document.getElementById('ordId').value;
  const o = oid ? (db.orders || []).find(x => x.id === oid) : null;
  if (!o) return alert('Save the order first, then sync.');
  if (!courierConfigured()) { alert('Set the Steadfast API key and secret in Settings → Courier first.'); return; }
  courierSyncOrders([o]).then(r => {
    renderOrderCourier();
    renderOrders();
    if (r.lines.length) alert('Courier:\n' + r.lines.join('\n'));
    else alert('Checked ' + r.checked + ' order — no new status.');
  });
}

/* Settings → Courier. The keys are written to this device only. */
function saveCourierSettings() {
  const k = document.getElementById('stCourierKey');
  const s = document.getElementById('stCourierSecret');
  const en = document.getElementById('stCourierEnabled');
  const cod = document.getElementById('stCourierAutoCod');
  const ret = document.getElementById('stCourierAutoReturn');
  try {
    if (k) localStorage.setItem(COURIER_KEY_KEY, String(k.value || '').trim());
    if (s) localStorage.setItem(COURIER_SECRET_KEY, String(s.value || '').trim());
  } catch (e) { alert('Could not save the courier keys: ' + e.message); return; }
  if (en) db.settings.courierEnabled = !!en.checked;
  if (cod) db.settings.courierAutoCod = !!cod.checked;
  if (ret) db.settings.courierAutoReturnGood = !!ret.checked;
  db.settings.settingsUpdatedAt = new Date().toISOString();
  commit();
  alert('Courier settings saved on this device.');
}

async function testCourierSettings() {
  const out = document.getElementById('courierTestOut');
  const say = m => { if (out) out.textContent = m; };
  if (!courierConfigured()) { say('Enter the API key and secret first.'); return; }
  say('Checking...');
  /* A balance call is the cheapest end-to-end proof the credentials work; it does not
     touch any parcel. */
  try {
    const res = await fetch(STEADFAST_API + '/get_balance', {
      headers: { 'Api-Key': courierKey(), 'Secret-Key': courierSecret() }
    });
    const j = await res.json().catch(() => null);
    if (res.status === 200 && j && j.status === 200) say('Connected. Balance: ৳' + num(j.current_balance));
    else say('Failed: ' + (j && j.message ? j.message : 'HTTP ' + res.status));
  } catch (e) { say('Could not reach Steadfast: ' + ((e && e.message) || e)); }
}

/* Auto-check on open and on a timer, muted, capped, and only while the tab is
   visible — the same discipline the cloud poll uses. Never blocks the app. */
var courierSyncing = false;
async function courierAutoSync() {
  if (courierSyncing || !courierEnabled() || typeof document === 'undefined' || document.hidden) return;
  const targets = courierSyncTargets_(db.orders, 8);
  if (!targets.length) return;
  courierSyncing = true;
  try {
    const r = await courierSyncOrders(targets);
    if (r.changed && currentPage === 'orders') renderOrders();
  } catch (e) { /* a courier outage must never break the app */ }
  courierSyncing = false;
}

/* ============================ booking a parcel ============================
   The tracking half above can only follow a parcel that already exists at
   Steadfast. This half creates it, so the whole courier job lives on the order
   itself and the owner never leaves the app to open the Steadfast portal.

   The invoice is deterministic per order (`TXP-<orderNo>`), so pressing Book
   twice, or a retry after a dropped reply, cannot create a second parcel: the
   same invoice is refused by Steadfast as a duplicate. The shipment is only
   recorded after Steadfast confirms, so a failed call never leaves an order
   claiming a parcel that was not really booked. */

/* Our idempotency key, sent to Steadfast as `invoice`. */
function courierInvoiceFor_(ord) {
  const no = String((ord && (ord.orderNo || ord.memoNo || ord.id)) || '').trim() || 'order';
  return 'TXP-' + no.replace(/[^A-Za-z0-9-]/g, '-');
}

/* A Bangladeshi mobile: 01 followed by 3-9, then eight more digits. */
function courierPhoneOk_(phone) {
  return /^01[3-9]\d{8}$/.test(String(phone || '').trim());
}

/* Where a parcel's recipient details come from, in priority order:
   the order's own fields, then the memo it settles, then the saved customer.
   Each falls back only when the field above it is blank, so a hand-typed value
   is never overwritten by a stale customer record. */
function courierBookingDraft(ord) {
  const memo = ord ? memoForOrder_(ord) : null;
  const cust = (db.customers || []).find(c =>
    (memo && c.name === memo.customerName && (c.phone || '') === (memo.customerPhone || '')) ||
    (!memo && c.name === (ord && ord.customerName)));
  const name = String((ord && ord.customerName) || (memo && memo.customerName) || (cust && cust.name) || '').trim();
  const phone = String((ord && ord.phone) || (memo && memo.customerPhone) || (cust && cust.phone) || '').trim();
  const address = String((memo && memo.customerAddress) || (cust && cust.address) || '').trim();
  /* Cash on delivery: what the memo still owes, less the advance already taken.
     Never negative, so a fully-paid memo books as 0 COD rather than a refund. */
  const cod = memo ? Math.max(0, num(memoRemainingDue(memo))) : 0;
  const desc = [ord && ord.productName, ord && num(ord.qty) ? '(' + num(ord.qty) + ' pcs)' : '']
    .filter(Boolean).join(' ');
  return { name, phone, address, cod, desc };
}

/* Build the Steadfast create_order payload. Pure, so a test can assert exactly
   what would be sent without a socket. */
function courierBookRequest_(ord, draft) {
  return {
    invoice: courierInvoiceFor_(ord),
    recipient_name: draft.name,
    recipient_phone: draft.phone,
    recipient_address: draft.address,
    cod_amount: num(draft.cod),
    item_description: draft.desc || undefined,
    delivery_type: 0
  };
}

/* Validate a draft before anything is sent. Returns an array of messages; empty
   means good to book. */
function courierBookErrors_(draft) {
  const errs = [];
  if (!String(draft.name || '').trim()) errs.push('Recipient name is required.');
  if (!courierPhoneOk_(draft.phone)) errs.push('A valid phone is required (01XXXXXXXXX).');
  if (!String(draft.address || '').trim()) errs.push('Delivery address is required.');
  if (num(draft.cod) < 0) errs.push('COD amount cannot be negative.');
  return errs;
}

/* Parse a create_order reply into {consignmentId, trackingCode}. Kept pure so the
   shapes Steadfast documents can be driven directly. */
function parseCourierBooking_(json) {
  const j = json || {};
  if (j.status && j.status !== 200) return { error: String(j.message || 'Steadfast refused the booking') };
  const c = j.consignment || j.data || j;
  const consignmentId = String((c && c.consignment_id) || '').trim();
  const trackingCode = String((c && c.tracking_code) || '').trim();
  if (!consignmentId) return { error: 'Steadfast did not return a consignment id.' };
  return { consignmentId, trackingCode };
}

/* The create_order HTTP call, isolated so tests stub exactly one seam. */
async function courierBookFetch_(payload) {
  if (!courierConfigured()) return { error: 'Courier API key/secret are not set (Settings → Courier).' };
  try {
    const res = await fetch(STEADFAST_API + '/create_order', {
      method: 'POST',
      headers: { 'Api-Key': courierKey(), 'Secret-Key': courierSecret(), 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const txt = await res.text();
    let j = null; try { j = JSON.parse(txt); } catch (e) { /* not JSON */ }
    if (j === null) {
      return { error: res.status === 401 || res.status === 403
        ? 'Steadfast rejected the API key (HTTP ' + res.status + '). Check Settings → Courier.'
        : 'Steadfast did not return JSON (HTTP ' + res.status + ').' };
    }
    return parseCourierBooking_(j);
  } catch (e) {
    return { error: 'Could not reach Steadfast: ' + ((e && e.message) || e) };
  }
}

/* The one place a booking changes records. `fetchOne` is injectable for tests;
   production passes nothing and uses courierBookFetch_. Returns {ok, error,
   shipment} and commits + queues the order once. */
async function courierBookOrder_(ord, draft, fetchOne) {
  const get = fetchOne || courierBookFetch_;
  const errs = courierBookErrors_(draft);
  if (errs.length) return { ok: false, error: errs.join(' ') };
  const payload = courierBookRequest_(ord, draft);
  const resp = await get(payload);
  if (resp.error) return { ok: false, error: resp.error };

  ord.consignmentId = resp.consignmentId;
  if (resp.trackingCode) {
    ord.trackingUrl = 'https://steadfast.com.bd/t/' + resp.trackingCode;
    ord.trackingCode = resp.trackingCode;
  }
  ord.courierStatus = 'pending';
  ord.courierCod = num(draft.cod);
  ord.courierBookedAt = new Date().toISOString();
  ord.courierCheckedAt = new Date().toISOString();
  ord.history = ord.history || [];
  ord.history.push({ at: new Date().toISOString(), text: 'Booked with Steadfast · ' + resp.consignmentId + ' · COD ' + money(num(draft.cod)) });
  commit();
  syncPush('order', {
    orderId: ord.id, orderNo: ord.orderNo, consignmentId: ord.consignmentId,
    courierStatus: ord.courierStatus, status: ord.status
  }, 'Courier booking ' + ord.orderNo);
  return { ok: true, shipment: { consignmentId: resp.consignmentId, trackingCode: resp.trackingCode } };
}

/* ---- the order modal's Courier block ---- */

/* Recompute the draft and paint the courier block: status badge, the fields the
   booking will use, and the Book / Sync buttons. Called whenever the order modal
   opens or a booking/sync finishes. */
function renderOrderCourier() {
  const box = document.getElementById('ordCourier');
  if (!box) return;
  const oid = document.getElementById('ordId').value;
  const o = oid ? (db.orders || []).find(x => x.id === oid) : null;
  const btn = document.getElementById('ordCourierSyncBtn');
  const bookBtn = document.getElementById('ordCourierBookBtn');
  const link = o && o.trackingUrl ? String(o.trackingUrl).trim() : '';
  const cid = (o && o.consignmentId) || '';
  const hasId = !!(cid || extractConsignment_(link));

  if (btn) btn.style.display = (o && (hasId || o.status === 'delivered')) ? '' : 'none';
  if (bookBtn) bookBtn.style.display = (o && !hasId) ? '' : 'none';

  /* Keep the two tracking fields in step with the order, so a later Save Order
     reads back the same consignment id a booking just stored rather than
     re-deriving a tracking code over it. Only fills a blank field, so a value
     the owner typed is never overwritten. */
  if (o) {
    const csEl = document.getElementById('ordConsignment');
    if (csEl && o.consignmentId && !String(csEl.value || '').trim()) csEl.value = o.consignmentId;
    const tuEl = document.getElementById('ordTrackingUrl');
    if (tuEl && o.trackingUrl && !String(tuEl.value || '').trim()) tuEl.value = o.trackingUrl;
  }

  if (!o) {
    box.innerHTML = '<div class="muted">Save the order first, then book the parcel and its ' +
      'Steadfast status will come back on its own.</div>';
    return;
  }
  if (!courierConfigured()) {
    box.innerHTML = '<div class="muted">Set the Steadfast API key in Settings → Courier to book ' +
      'and sync delivery status automatically.</div>';
    return;
  }

  const draft = courierBookingDraft(o);
  const errs = hasId ? [] : courierBookErrors_(draft);
  const statusPill = o.courierStatus
    ? '<span class="pill ' + (courierStatusFinal_(o.courierStatus) ? 'ok' : 'warn') + '">' +
      esc(courierStatusLabel_(o.courierStatus)) + '</span>'
    : '<span class="muted">Not booked yet</span>';

  let html = '<div class="row" style="gap:10px;flex-wrap:wrap">' +
    '<span><b>Courier:</b> ' + statusPill +
    (o.courierCheckedAt ? ' <span class="muted">· ' + esc(String(o.courierCheckedAt).slice(0, 16).replace('T', ' ')) + '</span>' : '') +
    (link ? ' <a href="' + esc(link) + '" target="_blank" rel="noopener">Open tracking ↗</a>' : '') +
    '</span></div>';

  if (!hasId) {
    html += '<div class="hint" style="margin-top:8px">Booking will send these details to Steadfast. ' +
      'Fix any blank field first — the address comes from the memo or the saved customer.</div>' +
      '<div class="formgrid" style="margin-top:8px">' +
      '<div><label>Recipient</label><input id="ordBookName" value="' + esc(draft.name) + '"></div>' +
      '<div><label>Phone</label><input id="ordBookPhone" value="' + esc(draft.phone) + '"></div>' +
      '<div class="wide"><label>Delivery Address</label><input id="ordBookAddress" value="' + esc(draft.address) + '"></div>' +
      '<div><label>COD Amount</label><input id="ordBookCod" type="number" min="0" step="1" value="' + num(draft.cod) + '"></div>' +
      '</div>';
    if (errs.length) html += '<div class="muted" style="color:var(--red);margin-top:6px">' + esc(errs.join(' ')) + '</div>';
  }
  box.innerHTML = html;
}

/* Read the courier fields off the modal, falling back to the computed draft when
   the booking form is not on screen (an already-booked order). */
function courierDraftFromForm_(ord) {
  const base = courierBookingDraft(ord);
  const v = id => { const e = document.getElementById(id); return e ? e.value : null; };
  return {
    name: v('ordBookName') != null ? String(v('ordBookName')).trim() : base.name,
    phone: v('ordBookPhone') != null ? String(v('ordBookPhone')).trim() : base.phone,
    address: v('ordBookAddress') != null ? String(v('ordBookAddress')).trim() : base.address,
    cod: v('ordBookCod') != null && v('ordBookCod') !== '' ? num(v('ordBookCod')) : base.cod,
    desc: base.desc
  };
}

/* Book the open order. The parcel is only booked once; a second press re-uses
   the consignment id already on the order rather than sending another parcel. */
function bookOrderCourier() {
  const oid = document.getElementById('ordId').value;
  const o = oid ? (db.orders || []).find(x => x.id === oid) : null;
  if (!o) return alert('Save the order first, then book.');
  if (o.consignmentId) return alert('This order already has a parcel (' + o.consignmentId + ').');
  if (!courierConfigured()) { alert('Set the Steadfast API key and secret in Settings → Courier first.'); return; }
  const draft = courierDraftFromForm_(o);
  const errs = courierBookErrors_(draft);
  if (errs.length) return alert(errs.join('\n'));
  if (!confirm('Book a Steadfast parcel for ' + (o.orderNo || 'this order') + '?\n\n' +
    'Recipient: ' + draft.name + '\nPhone: ' + draft.phone + '\nAddress: ' + draft.address +
    '\nCOD: ' + money(num(draft.cod)))) return;
  courierBookOrder_(o, draft).then(r => {
    if (!r.ok) { alert('Booking failed: ' + r.error); return; }
    renderOrderCourier();
    renderOrders();
    alert('Booked. Consignment ' + r.shipment.consignmentId + '. Status will sync automatically.');
  });
}

/* ===================== the memo's Steadfast label =====================
   A memo that has been booked with Steadfast has to carry the parcel's identity
   the way Steadfast's own label does, because the delivery man and the customer
   read it off the paper: the consignment id, in full, plus the scannable Code 128
   barcode of it. The barcode is drawn here as plain bars - no library - so the
   sheet stays a single self-contained file. */

/* Code 128 Set B patterns for values 0-106, as the 11-module bar/space strings
   from the standard. Set B covers the ASCII a consignment id and a tracking code
   are made of, so no code-set switching is needed. */
const CODE128_BARS_ = [
  '11011001100','11001101100','11001100110','10010011000','10010001100','10001001100',
  '10011001000','10011000100','10001100100','11001001000','11001000100','11000100100',
  '10110011100','10011011100','10011001110','10111001100','10011101100','10011100110',
  '11001110010','11001011100','11001001110','11011100100','11001110100','11101101110',
  '11101001100','11100101100','11100100110','11101100100','11100110100','11100110010',
  '11011011000','11011000110','11000110110','10100011000','10001011000','10001000110',
  '10110001000','10001101000','10001100010','11010001000','11000101000','11000100010',
  '10110111000','10110001110','10001101110','10111011000','10111000110','10001110110',
  '11101110110','11010001110','11000101110','11011101000','11011100010','11011101110',
  '11101011000','11101000110','11100010110','11101101000','11101100010','11100011010',
  '11101111010','11001000010','11110001010','10100110000','10100001100','10010110000',
  '10010000110','10000101100','10000100110','10110010000','10110000100','10011010000',
  '10011000010','10000110100','10000110010','11000010010','11001010000','11110111010',
  '11000010100','10001111010','10100111100','10010111100','10010011110','10111100100',
  '10011110100','10011110010','11110100100','11110010100','11110010010','11011011110',
  '11011110110','11110110110','10101111000','10100011110','10001011110','10111101000',
  '10111100010','11110101000','11110100010','10111011110','10111101110','11101011110',
  '11110101110','11010000100','11010010000','11010011100','1100011101011'
];

/* The module string for `text` in Code 128 Set B, including the start symbol, the
   mod-103 check symbol and the stop. Returns '' for characters Set B cannot carry,
   so the caller can fall back to printing the id without a barcode rather than a
   barcode that scans to the wrong thing. */
function code128Modules_(text) {
  const s = String(text == null ? '' : text);
  if (!s) return '';
  const values = [104];   // Start B
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 32 || c > 126) return '';
    values.push(c - 32);
  }
  let sum = values[0];
  for (let i = 1; i < values.length; i++) sum += values[i] * i;
  values.push(sum % 103);
  values.push(106);       // Stop
  return values.map(v => CODE128_BARS_[v]).join('');
}

/* The barcode as an inline SVG, sized so it reads at print size. Quiet zones are
   included because a barcode flush against a border often will not scan. */
function code128SVG_(text, height) {
  const mods = code128Modules_(text);
  if (!mods) return '';
  const quiet = 10, w = mods.length + quiet * 2, h = height || 44;
  let bars = '', x = quiet;
  for (let i = 0; i < mods.length; i++) {
    if (mods[i] === '1') bars += '<rect x="' + x + '" y="0" width="1" height="' + h + '"/>';
    x++;
  }
  return '<svg class="memo-bc-svg" xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h +
    '" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none">' +
    '<rect width="' + w + '" height="' + h + '" fill="#ffffff"/>' +
    '<g fill="#000000">' + bars + '</g></svg>';
}

/* The memo's Steadfast block, or '' when the memo has no parcel. The id is looked
   up from the order that settles the memo, which is where a booking records it. */
function memoSteadfastBlock(m) {
  if (!m) return '';
  const ord = (typeof orderForMemo_ === 'function') ? orderForMemo_(m) : null;
  const cid = ord ? String(ord.consignmentId || '').trim() : '';
  const code = ord ? String(ord.trackingCode || '').trim() : '';
  if (!cid && !code) return '';
  const scan = code || cid;
  return '<div class="memo-steadfast">' +
      '<div class="memo-sf-left">' +
        '<div class="memo-sf-tag">Steadfast Courier &#183; Consignment</div>' +
        '<div class="memo-sf-id">' + esc(cid || scan) + '</div>' +
        (code && cid ? '<div class="memo-sf-code">Tracking Code: <b>' + esc(code) + '</b></div>' : '') +
      '</div>' +
      '<div class="memo-sf-right">' + code128SVG_(scan, 46) + '</div>' +
    '</div>';
}

